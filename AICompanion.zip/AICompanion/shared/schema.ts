import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Conversations
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  userId: true,
  title: true,
});

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

// Messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => conversations.id).notNull(),
  content: text("content").notNull(),
  isUser: boolean("is_user").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  conversationId: true,
  content: true,
  isUser: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Travel Preferences
export const travelPreferences = pgTable("travel_preferences", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => conversations.id).notNull(),
  budget: text("budget").notNull(),
  duration: text("duration").notNull(),
  accommodationType: text("accommodation_type"),
  activities: text("activities").array(),
  destination: text("destination"),
  departureDateStr: text("departure_date"),
  returnDateStr: text("return_date"),
  numberOfTravelers: integer("number_of_travelers").default(1),
  currency: text("currency").default("DZD"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTravelPreferenceSchema = createInsertSchema(travelPreferences).pick({
  conversationId: true,
  budget: true,
  duration: true,
  accommodationType: true,
  activities: true,
  destination: true,
  departureDateStr: true,
  returnDateStr: true,
  numberOfTravelers: true,
  currency: true,
});

export type InsertTravelPreference = z.infer<typeof insertTravelPreferenceSchema>;
export type TravelPreference = typeof travelPreferences.$inferSelect;

// Travel Recommendations
export const travelRecommendations = pgTable("travel_recommendations", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => conversations.id).notNull(),
  destinations: jsonb("destinations").notNull(),
  travelPlan: jsonb("travel_plan"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTravelRecommendationSchema = createInsertSchema(travelRecommendations).pick({
  conversationId: true,
  destinations: true,
  travelPlan: true,
});

export type InsertTravelRecommendation = z.infer<typeof insertTravelRecommendationSchema>;
export type TravelRecommendation = typeof travelRecommendations.$inferSelect;
