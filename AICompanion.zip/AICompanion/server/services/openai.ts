import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

interface TravelPreferences {
  budget: string;
  duration: string;
  accommodationType: string;
  activities: string[];
  destination?: string;
  departureDateStr?: string;
  returnDateStr?: string;
  numberOfTravelers?: number;
  currency?: string;
}

interface Destination {
  name: string;
  country: string;
  imageUrl: string;
  safetyLevel: string;
  budgetSuitability: string;
  description: string;
  estimatedCost: string;
  recommendedAccommodation: string;
  flightPrices?: {
    economy: number;
    business?: number;
  };
  transportOptions?: {
    type: string;
    cost: string;
    description?: string;
  }[];
  promotions?: string[];
  currency?: string;
}

interface TravelPlanDay {
  day: string;
  activities: string;
  transport?: string;
}

interface TravelPlan {
  destination: string;
  duration: string;
  days: TravelPlanDay[];
}

interface TravelRecommendation {
  destinations: Destination[];
  travelPlan?: TravelPlan;
}

// Generate a welcome message for new users
export async function generateWelcomeMessage(): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI travel assistant for MusaferBox's 'Travel Alone' feature. You help users plan solo trips by providing personalized recommendations, flight bookings, and transportation options. Respond in Arabic with a warm, friendly welcome message explaining how you can help with solo travel planning."
        }
      ],
      max_tokens: 200
    });

    return response.choices[0].message.content || "مرحباً! أنا مساعد MusaferBox للسفر. كيف يمكنني مساعدتك في تخطيط رحلتك المنفردة التالية وحجز تذاكر الطيران والمواصلات؟";
  } catch (error) {
    console.error("Error generating welcome message:", error);
    return "مرحباً! أنا مساعد MusaferBox للسفر. كيف يمكنني مساعدتك في تخطيط رحلتك المنفردة التالية وحجز تذاكر الطيران والمواصلات؟";
  }
}

// Generate travel recommendations based on user preferences
export async function generateTravelRecommendations(
  preferences: TravelPreferences,
  conversationHistory: { role: "user" | "assistant"; content: string }[]
): Promise<TravelRecommendation> {
  try {
    const prompt = `
    Based on the following travel preferences, provide recommendations for solo travelers:
    - Budget: ${preferences.budget}
    - Duration: ${preferences.duration}
    - Accommodation Type: ${preferences.accommodationType}
    - Activities: ${preferences.activities.join(", ")}
    ${preferences.destination ? `- Preferred Destination: ${preferences.destination}` : ''}
    ${preferences.departureDateStr ? `- Departure Date: ${preferences.departureDateStr}` : ''}
    ${preferences.returnDateStr ? `- Return Date: ${preferences.returnDateStr}` : ''}
    ${preferences.numberOfTravelers ? `- Number of Travelers: ${preferences.numberOfTravelers}` : '- Number of Travelers: 1'}
    ${preferences.currency ? `- Currency: ${preferences.currency}` : '- Currency: DZD'}

    Provide recommendations in JSON format with the following structure:
    {
      "destinations": [
        {
          "name": "City Name",
          "country": "Country Name",
          "imageUrl": "URL to a relevant image from Unsplash",
          "safetyLevel": "Safety rating for solo travelers",
          "budgetSuitability": "Whether it fits within the budget",
          "description": "Brief description of the destination",
          "estimatedCost": "Estimated cost range for the trip",
          "recommendedAccommodation": "Specific accommodation recommendation",
          "flightPrices": {
            "economy": 500,
            "business": 1500
          },
          "transportOptions": [
            {
              "type": "Local Bus",
              "cost": "5-10 DZD per ride",
              "description": "Affordable local transportation"
            },
            {
              "type": "Taxi",
              "cost": "50-100 DZD per trip",
              "description": "Convenient for short distances"
            }
          ],
          "promotions": ["Special off-season discount", "Free airport pickup"],
          "currency": "DZD"
        }
      ],
      "travelPlan": {
        "destination": "Name of the first recommended destination",
        "duration": "${preferences.duration}",
        "days": [
          {
            "day": "1-2",
            "activities": "Description of activities",
            "transport": "Recommended transportation for these activities"
          }
        ]
      }
    }

    Provide 2-3 destinations that are appropriate for solo travelers, safe, and within the specified budget.
    Make sure to provide actual Unsplash image URLs for the destinations and include flight pricing in both economy and business class.
    Always include transport options within each destination with approximate costs in the specified currency.
    `;

    const messages = [
      {
        role: "system",
        content: "You are an AI travel assistant for MusaferBox's 'Travel Alone' feature. You provide detailed, personalized travel recommendations for solo travelers based on their preferences. Your recommendations should be safe, budget-appropriate, and tailored for solo travel experiences. Include information about flight pricing in DZD and transportation options."
      },
      ...conversationHistory,
      { role: "user", content: prompt }
    ];

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: messages as any,
      response_format: { type: "json_object" },
      max_tokens: 1500
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result as TravelRecommendation;
  } catch (error) {
    console.error("Error generating travel recommendations:", error);
    
    // Fallback response in case of API error
    return {
      destinations: [
        {
          name: "بالي",
          country: "إندونيسيا",
          imageUrl: "https://images.unsplash.com/photo-1583226728626-ad4c43f61488",
          safetyLevel: "آمنة للمسافرين المنفردين",
          budgetSuitability: "ضمن الميزانية",
          description: "تعتبر بالي وجهة رائعة للمسافرين المنفردين مع مجتمع ودود وبنية تحتية جيدة للسياحة.",
          estimatedCost: "1000-1300 دولار للأسبوع",
          recommendedAccommodation: "نزل في أوبود أو سيمينياك"
        }
      ],
      travelPlan: {
        destination: "بالي",
        duration: preferences.duration,
        days: [
          {
            day: "1-2",
            activities: "استكشاف أوبود، زيارة معبد تيرتا إمبول، غابة القرود"
          },
          {
            day: "3-4",
            activities: "شاطئ كوتا، تعلم ركوب الأمواج، استكشاف سيمينياك"
          }
        ]
      }
    };
  }
}

// Answer user questions about travel
export async function answerTravelQuestion(
  question: string,
  preferences: TravelPreferences | null,
  conversationHistory: { role: "user" | "assistant"; content: string }[]
): Promise<string> {
  try {
    let systemPrompt = "You are an AI travel assistant for MusaferBox's 'Travel Alone' feature. You provide helpful, informative answers to questions about solo travel, flight booking, and transportation options. Your responses should be detailed, accurate, and tailored for solo travelers. Respond in Arabic.";
    
    if (preferences) {
      systemPrompt += `\n\nThe user has the following travel preferences:
      - Budget: ${preferences.budget}
      - Duration: ${preferences.duration}
      - Accommodation Type: ${preferences.accommodationType}
      - Activities: ${preferences.activities.join(", ")}
      
      Consider these preferences when answering their questions.`;
    }

    const messages = [
      { role: "system", content: systemPrompt },
      ...conversationHistory,
      { role: "user", content: question }
    ];

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: messages as any,
      max_tokens: 800
    });

    return response.choices[0].message.content || "عذراً، لم أستطع معالجة سؤالك. يرجى المحاولة مرة أخرى.";
  } catch (error) {
    console.error("Error answering travel question:", error);
    return "عذراً، حدث خطأ أثناء معالجة سؤالك. يرجى المحاولة مرة أخرى.";
  }
}
