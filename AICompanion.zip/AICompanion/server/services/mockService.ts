// mockService.ts - A service that provides mock data for AI responses
// Used as a fallback when external API services are unavailable

// Mock Data Types
interface TravelPreferences {
  budget: string;
  duration: string;
  accommodationType: string;
  activities: string[];
  destination?: string;
  departureDateStr?: string;
  returnDateStr?: string;
  numberOfTravelers?: number;
  currency?: string;
}

interface Destination {
  name: string;
  country: string;
  imageUrl: string;
  safetyLevel: string;
  budgetSuitability: string;
  description: string;
  estimatedCost: string;
  recommendedAccommodation: string;
  flightPrices?: {
    economy: number;
    business?: number;
  };
  transportOptions?: {
    type: string;
    cost: string;
    description?: string;
  }[];
  promotions?: string[];
  currency?: string;
}

interface TravelPlanDay {
  day: string;
  activities: string;
  transport?: string;
}

interface TravelPlan {
  destination: string;
  duration: string;
  days: TravelPlanDay[];
}

interface TravelRecommendation {
  destinations: Destination[];
  travelPlan?: TravelPlan;
}

// Generate welcome message
export async function generateWelcomeMessage(): Promise<string> {
  return "مرحباً بك في MusaferBox! أنا هنا لمساعدتك في تخطيط رحلتك المنفردة. أخبرني عن تفضيلاتك من حيث الميزانية والمدة ونوع الإقامة والأنشطة التي تفضلها ووسائل النقل المفضلة، وسأقدم لك توصيات مخصصة.";
}

// Generate travel recommendations
export async function generateTravelRecommendations(
  preferences: TravelPreferences,
): Promise<TravelRecommendation> {
  // We'll create realistic mock data based on preferences
  const budgetMap: { [key: string]: string } = {
    'منخفضة': 'اقتصادي',
    'متوسطة': 'متوسط',
    'مرتفعة': 'مرتفع'
  };

  // Default currency to DZD if not specified
  const currency = preferences.currency || 'DZD';
  
  // Determine budget level from preferences
  const budgetLevel = preferences.budget.includes('منخفضة') ? 'منخفضة' : 
                     preferences.budget.includes('متوسطة') ? 'متوسطة' : 'مرتفعة';
  
  // Set a fixed conversion rate from USD to DZD
  const usdToDzdRate = 135.27;
  
  // Create destinations based on budget and activities
  const destinations: Destination[] = [];
  
  // Hiking/Nature destination
  if (preferences.activities.some(act => act.includes('طبيعة') || act.includes('تسلق') || act.includes('مشي'))) {
    destinations.push({
      name: "الألب السويسرية",
      country: "سويسرا",
      imageUrl: "https://images.unsplash.com/photo-1531210483974-4f8c1f33fd35",
      safetyLevel: "آمنة جداً",
      budgetSuitability: budgetMap[budgetLevel],
      description: "مناظر طبيعية خلابة، مسارات للمشي لمسافات طويلة، وأنشطة في الهواء الطلق.",
      estimatedCost: budgetLevel === 'منخفضة' ? "1500-2000 دولار" : budgetLevel === 'متوسطة' ? "2500-3500 دولار" : "4000-5500 دولار",
      recommendedAccommodation: budgetLevel === 'منخفضة' ? "نزل للشباب في انترلاكن" : budgetLevel === 'متوسطة' ? "فندق جبلي متوسط المستوى" : "منتجع فاخر مع إطلالة على الجبال",
      flightPrices: {
        economy: budgetLevel === 'منخفضة' ? 600 : budgetLevel === 'متوسطة' ? 850 : 1200,
        business: budgetLevel === 'متوسطة' ? 2500 : 3800
      },
      transportOptions: [
        {
          type: "قطار",
          cost: "60-100 فرنك سويسري",
          description: "شبكة قطارات ممتازة تصل إلى معظم المناطق السياحية"
        },
        {
          type: "حافلة",
          cost: "10-20 فرنك سويسري",
          description: "متوفرة في المدن والقرى الرئيسية"
        },
        {
          type: "تلفريك",
          cost: "30-80 فرنك سويسري",
          description: "للوصول إلى القمم والمناطق المرتفعة"
        }
      ],
      promotions: budgetLevel === 'منخفضة' ? ["بطاقة Swiss Travel Pass المخفضة للمسافرين المنفردين"] : ["خصم 15% على الرحلات الاستكشافية الجبلية"],
      currency: currency
    });
  }
  
  // Beach destination
  if (preferences.activities.some(act => act.includes('شاطئ') || act.includes('بحر') || act.includes('سباحة'))) {
    destinations.push({
      name: "بالي",
      country: "إندونيسيا",
      imageUrl: "https://images.unsplash.com/photo-1558005530-a7958896ec60",
      safetyLevel: "آمنة للمسافرين المنفردين",
      budgetSuitability: budgetMap[budgetLevel],
      description: "شواطئ خلابة، ثقافة غنية، وأنشطة مائية متنوعة.",
      estimatedCost: budgetLevel === 'منخفضة' ? "800-1200 دولار" : budgetLevel === 'متوسطة' ? "1500-2500 دولار" : "3000-4500 دولار",
      recommendedAccommodation: budgetLevel === 'منخفضة' ? "نزل في كوتا" : budgetLevel === 'متوسطة' ? "فيلا صغيرة في أوبود" : "منتجع فاخر على الشاطئ",
      flightPrices: {
        economy: budgetLevel === 'منخفضة' ? 750 : budgetLevel === 'متوسطة' ? 950 : 1400,
        business: budgetLevel === 'متوسطة' ? 2800 : 4200
      },
      transportOptions: [
        {
          type: "سكوتر",
          cost: "5-10 دولار/يوم",
          description: "وسيلة نقل شائعة ومناسبة للمسافات القصيرة"
        },
        {
          type: "سيارة مع سائق",
          cost: "40-60 دولار/يوم",
          description: "خيار مريح للرحلات الطويلة واستكشاف الجزيرة"
        },
        {
          type: "حافلة",
          cost: "1-3 دولار/رحلة",
          description: "اقتصادية ولكنها قد تكون مزدحمة وبطيئة"
        }
      ],
      promotions: ["خصم 20% على جلسات اليوغا وأنشطة الاسترخاء", "استقبال مجاني من المطار مع حجز 5 ليالي"],
      currency: currency
    });
  }
  
  // Cultural destination
  if (preferences.activities.some(act => act.includes('ثقافة') || act.includes('تاريخ') || act.includes('متاحف'))) {
    destinations.push({
      name: "كيوتو",
      country: "اليابان",
      imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e",
      safetyLevel: "آمنة جداً",
      budgetSuitability: budgetMap[budgetLevel],
      description: "مدينة تاريخية تجمع بين التقاليد اليابانية العريقة والحداثة.",
      estimatedCost: budgetLevel === 'منخفضة' ? "1200-1800 دولار" : budgetLevel === 'متوسطة' ? "2000-3000 دولار" : "4000-6000 دولار",
      recommendedAccommodation: budgetLevel === 'منخفضة' ? "نزل تقليدي ياباني" : budgetLevel === 'متوسطة' ? "فندق متوسط في وسط المدينة" : "رويكان تقليدي فاخر",
      flightPrices: {
        economy: budgetLevel === 'منخفضة' ? 900 : budgetLevel === 'متوسطة' ? 1200 : 1800,
        business: budgetLevel === 'متوسطة' ? 3500 : 5200
      },
      transportOptions: [
        {
          type: "قطار",
          cost: "4-12 دولار/رحلة",
          description: "شبكة قطارات سريعة ودقيقة"
        },
        {
          type: "دراجة هوائية",
          cost: "10-15 دولار/يوم",
          description: "وسيلة رائعة لاستكشاف المدينة"
        },
        {
          type: "حافلة سياحية",
          cost: "25-40 دولار/يوم",
          description: "متوفرة للوصول إلى المعالم السياحية الرئيسية"
        }
      ],
      promotions: ["بطاقة Kyoto Cultural Pass مع خصم 25% على المتاحف والمعابد"],
      currency: currency
    });
  }
  
  // If no specific destination types were detected, add a general destination
  if (destinations.length === 0) {
    destinations.push({
      name: "برشلونة",
      country: "إسبانيا",
      imageUrl: "https://images.unsplash.com/photo-1558642084-fd07fae5282e",
      safetyLevel: "آمنة",
      budgetSuitability: budgetMap[budgetLevel],
      description: "مدينة نابضة بالحياة تجمع بين الثقافة والشواطئ والهندسة المعمارية الفريدة.",
      estimatedCost: budgetLevel === 'منخفضة' ? "900-1400 دولار" : budgetLevel === 'متوسطة' ? "1600-2500 دولار" : "3000-4500 دولار",
      recommendedAccommodation: budgetLevel === 'منخفضة' ? "نزل في الحي القوطي" : budgetLevel === 'متوسطة' ? "شقة في إيكسامبل" : "فندق فاخر بالقرب من باسيج دي غراسيا",
      flightPrices: {
        economy: budgetLevel === 'منخفضة' ? 550 : budgetLevel === 'متوسطة' ? 750 : 1100,
        business: budgetLevel === 'متوسطة' ? 2200 : 3400
      },
      transportOptions: [
        {
          type: "مترو",
          cost: "2.40 يورو/رحلة أو 11 يورو/10 رحلات",
          description: "يغطي معظم أنحاء المدينة، سريع وموثوق"
        },
        {
          type: "حافلة",
          cost: "2.40 يورو/رحلة",
          description: "شبكة واسعة تصل إلى مناطق لا يصل إليها المترو"
        },
        {
          type: "تاكسي",
          cost: "10-15 يورو للرحلات القصيرة",
          description: "متوفر على مدار الساعة، مريح للرحلات الليلية"
        }
      ],
      promotions: ["Barcelona City Pass مع دخول مجاني للمعالم الرئيسية"],
      currency: currency
    });
  }
  
  // Create a travel plan for the first destination
  const mainDestination = destinations[0];
  const durationDays = parseInt(preferences.duration.replace(/[^\d]/g, '')) || 7;
  
  const travelPlan: TravelPlan = {
    destination: mainDestination.name,
    duration: preferences.duration,
    days: []
  };
  
  // Fill days with activities and transport based on the destination
  if (mainDestination.name === "الألب السويسرية") {
    travelPlan.days = [
      { 
        day: "1", 
        activities: "الوصول إلى زيورخ والانتقال إلى انترلاكن. استكشاف وسط مدينة انترلاكن.",
        transport: "قطار من المطار إلى انترلاكن"
      },
      { 
        day: "2", 
        activities: "رحلة إلى قمة يونغفراويوخ - أعلى محطة قطار في أوروبا، مع إطلالات خلابة.",
        transport: "قطار الجبل"
      },
      { 
        day: "3", 
        activities: "مشي لمسافات طويلة في مسارات لاوتربرونن والاستمتاع بمشاهدة الشلالات.",
        transport: "حافلة ومشي"
      }
    ];
    
    // Add more days if duration is longer
    if (durationDays > 3) {
      travelPlan.days.push({ 
        day: "4", 
        activities: "زيارة بحيرة برينز والاستمتاع برحلة بالقارب.",
        transport: "قطار وقارب"
      });
    }
    
    if (durationDays > 4) {
      travelPlan.days.push({ 
        day: "5", 
        activities: "استكشاف مدينة لوسيرن التاريخية وبحيرتها الجميلة.",
        transport: "قطار (رحلة يومية)"
      });
    }
    
    if (durationDays > 5) {
      travelPlan.days.push({ 
        day: "6-" + durationDays, 
        activities: "زيارة غريندلفالد واستكشاف مسارات المشي في منطقة أيغر.",
        transport: "قطار ومشي"
      });
    }
  } 
  else if (mainDestination.name === "بالي") {
    travelPlan.days = [
      { 
        day: "1", 
        activities: "الوصول إلى مطار دنباسار والانتقال إلى كوتا. راحة والتأقلم مع المكان.",
        transport: "تاكسي من المطار"
      },
      { 
        day: "2", 
        activities: "يوم على شاطئ كوتا، مع دروس في ركوب الأمواج للمبتدئين.",
        transport: "سير على الأقدام أو سكوتر"
      },
      { 
        day: "3", 
        activities: "الانتقال إلى أوبود، ثم زيارة معبد تيرتا إمبول وغابة القرود.",
        transport: "سيارة خاصة مع سائق أو حافلة"
      }
    ];
    
    if (durationDays > 3) {
      travelPlan.days.push({ 
        day: "4", 
        activities: "صباح اليوغا في أوبود، ثم زيارة حقول الأرز الشهيرة.",
        transport: "سكوتر أو دراجة هوائية"
      });
    }
    
    if (durationDays > 4) {
      travelPlan.days.push({ 
        day: "5", 
        activities: "رحلة إلى شواطئ أولوواتو وزيارة معبد أولوواتو لمشاهدة رقصة كيشاك عند غروب الشمس.",
        transport: "سيارة مع سائق"
      });
    }
    
    if (durationDays > 5) {
      travelPlan.days.push({ 
        day: "6-" + durationDays, 
        activities: "رحلة إلى جزر جيلي للغطس والاسترخاء على الشاطئ.",
        transport: "قارب سريع إلى الجزر"
      });
    }
  }
  else if (mainDestination.name === "كيوتو") {
    travelPlan.days = [
      { 
        day: "1", 
        activities: "الوصول والانتقال إلى الفندق. استكشاف منطقة المحطة وسوق نيشيكي.",
        transport: "قطار ومشي"
      },
      { 
        day: "2", 
        activities: "زيارة معبد كينكاكوجي (معبد الذهب) ومعبد روانجي وقصر نيجو.",
        transport: "حافلة سياحية"
      },
      { 
        day: "3", 
        activities: "استكشاف منطقة أرشيوميا، غابة الخيزران، ومعبد تينريوجي.",
        transport: "قطار JR ومشي"
      }
    ];
    
    if (durationDays > 3) {
      travelPlan.days.push({ 
        day: "4", 
        activities: "زيارة فوشيمي إيناري وممراته الشهيرة من البوابات الحمراء.",
        transport: "قطار JR"
      });
    }
    
    if (durationDays > 4) {
      travelPlan.days.push({ 
        day: "5", 
        activities: "رحلة يومية إلى نارا لرؤية المعابد القديمة والغزلان المقدسة.",
        transport: "قطار JR (رحلة يومية)"
      });
    }
    
    if (durationDays > 5) {
      travelPlan.days.push({ 
        day: "6-" + durationDays, 
        activities: "زيارة منطقة جيون التقليدية ومشاهدة عرض الجيشا.",
        transport: "حافلة ومشي"
      });
    }
  }
  else { // Barcelona
    travelPlan.days = [
      { 
        day: "1", 
        activities: "الوصول والانتقال إلى الفندق. استكشاف شارع لا رامبلا وسوق بوكيريا.",
        transport: "مترو من المطار"
      },
      { 
        day: "2", 
        activities: "زيارة الحي القوطي، كاتدرائية برشلونة، ومتحف بيكاسو.",
        transport: "مشي ومترو"
      },
      { 
        day: "3", 
        activities: "استكشاف أعمال غاودي: ساغرادا فاميليا وبارك غويل.",
        transport: "مترو وحافلة"
      }
    ];
    
    if (durationDays > 3) {
      travelPlan.days.push({ 
        day: "4", 
        activities: "يوم على شاطئ برشلونيتا والاستمتاع بالمأكولات البحرية.",
        transport: "مشي أو مترو"
      });
    }
    
    if (durationDays > 4) {
      travelPlan.days.push({ 
        day: "5", 
        activities: "زيارة مونتجويك، متحف الفن الوطني الكتالوني، والنافورة السحرية.",
        transport: "تلفريك ومترو"
      });
    }
    
    if (durationDays > 5) {
      travelPlan.days.push({ 
        day: "6-" + durationDays, 
        activities: "رحلة يومية إلى مونتسيرات.",
        transport: "قطار FGC (رحلة يومية)"
      });
    }
  }
  
  return {
    destinations,
    travelPlan
  };
}

// Answer user questions about travel
export async function answerTravelQuestion(
  conversationHistory: string,
  question: string
): Promise<string> {
  // Determine if the question is about flights, transport, or general travel
  const lowerQuestion = question.toLowerCase();
  
  if (lowerQuestion.includes('طيران') || lowerQuestion.includes('تذكرة') || lowerQuestion.includes('تذاكر') || lowerQuestion.includes('مطار')) {
    return "بالنسبة لتذاكر الطيران، نوصي بحجزها قبل 2-3 أشهر من موعد سفرك للحصول على أفضل الأسعار. يمكنك الاطلاع على أسعار الرحلات المباشرة والعروض الخاصة في تبويب 'تذاكر الطيران' لكل وجهة. للمسافرين المنفردين، غالباً ما تكون الدرجة الاقتصادية هي الخيار الأفضل من حيث القيمة مقابل المال. نقدم أيضاً خدمة مساعدة في حجز التذاكر - يمكنك التواصل مع فريق MusaferBox عبر التطبيق لمزيد من المساعدة.";
  }
  
  if (lowerQuestion.includes('نقل') || lowerQuestion.includes('مواصلات') || lowerQuestion.includes('حافلة') || lowerQuestion.includes('قطار') || lowerQuestion.includes('سيارة')) {
    return "تختلف خيارات النقل من وجهة إلى أخرى. في المدن الأوروبية، غالباً ما تكون شبكة النقل العام (مترو، حافلات، ترام) هي الخيار الأفضل للمسافرين المنفردين من حيث السهولة والتكلفة. في آسيا، يمكن أن تكون الدراجات النارية (سكوتر) خياراً اقتصادياً في بلدان مثل تايلاند وفيتنام وبالي. للمسافات الطويلة بين المدن، القطارات غالباً ما تكون الخيار الأكثر راحة وملاءمة للمسافرين المنفردين. يمكنك الاطلاع على تفاصيل وتكاليف وسائل النقل المتاحة في كل وجهة ضمن تبويب 'المواصلات'.";
  }
  
  if (lowerQuestion.includes('وحدي') || lowerQuestion.includes('منفرد') || lowerQuestion.includes('سلامة') || lowerQuestion.includes('امان') || lowerQuestion.includes('أمان')) {
    return "السفر بمفردك يمكن أن يكون تجربة رائعة وغنية! للسلامة، ننصح باختيار وجهات معروفة بكونها آمنة للمسافرين المنفردين مثل اليابان، سويسرا، نيوزيلندا، وسنغافورة. احرص على إبقاء أحد أفراد العائلة أو الأصدقاء على اطلاع بخط سير رحلتك، واحتفظ بنسخة من أوراقك الثبوتية في مكان منفصل. استخدم النزل الشبابية (Hostels) للالتقاء بمسافرين آخرين. أيضاً، ثق بحدسك دائماً - إذا شعرت بعدم الارتياح في موقف ما، غادر واطلب المساعدة. تقدم MusaferBox خدمة متابعة للمسافرين المنفردين للاطمئنان عليهم خلال رحلتهم.";
  }
  
  if (lowerQuestion.includes('ميزانية') || lowerQuestion.includes('تكلفة') || lowerQuestion.includes('سعر') || lowerQuestion.includes('رخيص') || lowerQuestion.includes('غالي')) {
    return "تختلف تكاليف السفر بشكل كبير حسب الوجهة وأسلوب السفر. بشكل عام، جنوب شرق آسيا (تايلاند، فيتنام، إندونيسيا) والبلقان (صربيا، ألبانيا، البوسنة) تعتبر وجهات اقتصادية للمسافرين المنفردين. يمكنك توفير المال عن طريق الإقامة في النزل الشبابية أو استخدام منصات مثل Airbnb، وتناول الطعام في المطاعم المحلية بدلاً من المطاعم السياحية، واستخدام وسائل النقل العام. نقدم في MusaferBox تصنيفاً للوجهات حسب مدى ملاءمتها للميزانية (اقتصادي، متوسط، مرتفع) لمساعدتك في التخطيط المالي لرحلتك.";
  }
  
  // Default response for general questions
  return "شكراً على سؤالك! يمكنني مساعدتك في التخطيط لرحلتك المنفردة، بما في ذلك اقتراح وجهات تناسب تفضيلاتك، وتقديم معلومات عن الإقامة، وسائل النقل، والأنشطة المتاحة. للحصول على توصيات مخصصة أكثر، يرجى مشاركة تفضيلاتك من حيث الميزانية، المدة، نوع الإقامة المفضل، والأنشطة التي تهتم بها. فريق MusaferBox متاح دائماً لتقديم الدعم أثناء رحلتك.";
}