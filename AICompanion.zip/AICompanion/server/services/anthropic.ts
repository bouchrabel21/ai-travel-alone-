import Anthropic from '@anthropic-ai/sdk';

// the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface TravelPreferences {
  budget: string;
  duration: string;
  accommodationType: string;
  activities: string[];
  destination?: string;
  departureDateStr?: string;
  returnDateStr?: string;
  numberOfTravelers?: number;
  currency?: string;
}

interface Destination {
  name: string;
  country: string;
  imageUrl: string;
  safetyLevel: string;
  budgetSuitability: string;
  description: string;
  estimatedCost: string;
  recommendedAccommodation: string;
  flightPrices?: {
    economy: number;
    business?: number;
  };
  promotions?: string[];
  currency?: string;
}

interface TravelPlanDay {
  day: string;
  activities: string;
}

interface TravelPlan {
  destination: string;
  duration: string;
  days: TravelPlanDay[];
}

interface TravelRecommendation {
  destinations: Destination[];
  travelPlan?: TravelPlan;
}

export async function generateWelcomeMessage(): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: 'أنت مساعد سفر من Musaferox. قدم رسالة ترحيب باللغة العربية تشرح كيف يمكنك مساعدة المستخدم في تخطيط رحلته المنفردة. اجعل الرسالة ودية وموجزة. اطلب من المستخدم تفضيلاته للسفر (الميزانية، المدة، نوع الإقامة، الأنشطة، وجهة سفر محددة إذا كان يعرف، ووسائل النقل المفضلة).'
        }
      ],
    });

    // Handle different content block types safely
    if (response.content[0].type === 'text') {
      return response.content[0].text;
    } else {
      return "مرحباً بك في MusaferBox! أنا هنا لمساعدتك في تخطيط رحلتك المنفردة. أخبرني عن تفضيلاتك من حيث الميزانية والمدة ونوع الإقامة والأنشطة التي تفضلها ووسائل النقل المفضلة، وسأقدم لك توصيات مخصصة.";
    }
  } catch (error) {
    console.error('Error generating welcome message with Anthropic:', error);
    throw error;
  }
}

export async function generateTravelRecommendations(
  preferences: TravelPreferences,
): Promise<TravelRecommendation> {
  try {
    // Create a prompt based on user preferences
    const prompt = `
    أنت مستشار سفر خبير من MusaferBox. بناءً على تفضيلات المستخدم التالية، قدم توصيات سفر مخصصة:
    
    الميزانية: ${preferences.budget}
    المدة: ${preferences.duration}
    نوع الإقامة: ${preferences.accommodationType}
    الأنشطة المفضلة: ${preferences.activities.join(', ')}
    ${preferences.destination ? `الوجهة المفضلة: ${preferences.destination}` : ''}
    ${preferences.departureDateStr ? `تاريخ المغادرة: ${preferences.departureDateStr}` : ''}
    ${preferences.returnDateStr ? `تاريخ العودة: ${preferences.returnDateStr}` : ''}
    ${preferences.numberOfTravelers ? `عدد المسافرين: ${preferences.numberOfTravelers}` : 'عدد المسافرين: 1'}
    ${preferences.currency ? `العملة: ${preferences.currency}` : 'العملة: DZD'}
    
    قدم ثلاث وجهات مقترحة مع المعلومات التالية لكل منها:
    1. اسم المكان والدولة
    2. رابط صورة (استخدم صورًا عامة متاحة على الإنترنت)
    3. مستوى الأمان (آمن جدًا، آمن، متوسط الأمان)
    4. مدى ملاءمة الميزانية (اقتصادي، متوسط، مرتفع)
    5. وصف موجز عن المكان
    6. تكلفة تقديرية للرحلة
    7. أماكن إقامة مقترحة (فندق أو نزل أو شقة محددة)
    8. أسعار تذاكر الطيران بالدرجة الاقتصادية والأعمال بالدولار الأمريكي
    9. عروض ترويجية إن وجدت
    10. وسائل النقل المتاحة داخل الوجهة وتكلفتها التقريبية
    
    ثم قدم خطة سفر مفصلة لأفضل وجهة تناسب تفضيلات المستخدم. يجب أن تتضمن الخطة:
    1. اسم الوجهة
    2. مدة الرحلة
    3. جدول يومي بالأنشطة المقترحة ووسائل النقل المناسبة لكل يوم
    
    أعطني النتيجة بتنسيق JSON يتضمن:
    - مصفوفة "destinations" تحتوي على كائنات بالتفاصيل المذكورة أعلاه
    - كائن "travelPlan" يحتوي على خطة السفر المفصلة
    
    لكل وجهة، أضف حقل flightPrices يحتوي على أسعار الطيران بالدولار لكل من economy و business.
    أضف أيضًا حقل transportOptions يحتوي على معلومات عن وسائل النقل المتاحة داخل الوجهة.
    أضف أيضًا حقل promotions يحتوي على مصفوفة من العروض الترويجية للوجهة إن وجدت.
    `;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 3000,
      messages: [
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
    });

    // Parse the JSON response
    let content = '';
    if (response.content[0].type === 'text') {
      content = response.content[0].text;
    } else {
      throw new Error('Unexpected response format from Anthropic API');
    }
    
    const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || 
                      content.match(/```\n([\s\S]*?)\n```/) || 
                      content.match(/{[\s\S]*?}/);
                      
    let jsonContent = '';
    if (jsonMatch) {
      jsonContent = jsonMatch[1] || jsonMatch[0];
    } else {
      jsonContent = content;
    }

    const cleanedJson = jsonContent.replace(/^```json\n|^```\n|```$/g, '').trim();
    const recommendations = JSON.parse(cleanedJson) as TravelRecommendation;

    return recommendations;
  } catch (error) {
    console.error('Error generating travel recommendations with Anthropic:', error);
    throw error;
  }
}

export async function answerTravelQuestion(
  conversationHistory: string,
  question: string
): Promise<string> {
  try {
    const prompt = `
    أنت مستشار سفر خبير من MusaferBox. أجب على سؤال المستخدم حول السفر بناءً على المحادثة السابقة.
    تأكد من توفير معلومات مفصلة عن أسعار الطيران ووسائل النقل المتاحة عندما يكون ذلك مناسباً.
    
    المحادثة السابقة:
    ${conversationHistory}
    
    سؤال المستخدم:
    ${question}
    
    قدم إجابة مفيدة ومفصلة. إذا كنت لا تعرف الإجابة، اقترح البحث عن مزيد من المعلومات.
    `;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
    });

    // Check if the response contains text content
    if (response.content[0].type === 'text') {
      return response.content[0].text;
    } else {
      return "عذراً، لم أتمكن من معالجة هذا السؤال. يرجى المحاولة مرة أخرى أو طرح سؤال مختلف.";
    }
  } catch (error) {
    console.error('Error answering travel question with Anthropic:', error);
    throw error;
  }
}