import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertConversationSchema, insertMessageSchema, insertTravelPreferenceSchema, insertTravelRecommendationSchema } from "@shared/schema";
import * as openaiService from "./services/openai";
import * as anthropicService from "./services/anthropic";
import * as mockService from "./services/mockService";

// API key checks
if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set. Will try to use Anthropic API instead.");
}

if (!process.env.ANTHROPIC_API_KEY) {
  console.warn("ANTHROPIC_API_KEY is not set. Will try to use OpenAI API instead.");
}

// AI service with Mock as primary and external APIs as fallback
const aiService = {
  generateWelcomeMessage: async (): Promise<string> => {
    try {
      console.log("Using mockService for welcome message");
      return await mockService.generateWelcomeMessage();
    } catch (error) {
      console.log("Mock service error, trying external APIs:", error instanceof Error ? error.message : String(error));
      try {
        return await anthropicService.generateWelcomeMessage();
      } catch (error) {
        console.log("Anthropic error, falling back to OpenAI:", error instanceof Error ? error.message : String(error));
        return await openaiService.generateWelcomeMessage();
      }
    }
  },
  
  generateTravelRecommendations: async (
    preferences: any,
    conversationHistory?: any
  ) => {
    try {
      console.log("Using mockService for travel recommendations");
      return await mockService.generateTravelRecommendations(preferences);
    } catch (error) {
      console.log("Mock service error, trying external APIs:", error instanceof Error ? error.message : String(error));
      try {
        return await anthropicService.generateTravelRecommendations(preferences);
      } catch (error) {
        console.log("Anthropic error, falling back to OpenAI:", error instanceof Error ? error.message : String(error));
        return await openaiService.generateTravelRecommendations(preferences, conversationHistory);
      }
    }
  },
  
  answerTravelQuestion: async (
    question: string,
    preferences?: any,
    conversationHistory?: any
  ) => {
    try {
      // Convert conversation history format
      const conversationText = conversationHistory
        ? conversationHistory.map((msg: any) => `${msg.role === 'user' ? 'User: ' : 'Assistant: '}${msg.content}`).join('\n\n')
        : '';
      
      console.log("Using mockService for answering travel question");
      return await mockService.answerTravelQuestion(conversationText, question);
    } catch (error) {
      console.log("Mock service error, trying external APIs:", error instanceof Error ? error.message : String(error));
      try {
        return await anthropicService.answerTravelQuestion(conversationText, question);
      } catch (error) {
        console.log("Anthropic error, falling back to OpenAI:", error instanceof Error ? error.message : String(error));
        return await openaiService.answerTravelQuestion(question, preferences, conversationHistory);
      }
    }
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // Create a new conversation
  app.post("/api/conversations", async (req, res) => {
    try {
      const parsedBody = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(parsedBody);
      
      // Generate and save welcome message
      const welcomeMessage = await aiService.generateWelcomeMessage();
      await storage.createMessage({
        conversationId: conversation.id,
        content: welcomeMessage,
        isUser: false
      });
      
      res.status(201).json(conversation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create conversation" });
      }
    }
  });

  // Get all conversations for a user
  app.get("/api/users/:userId/conversations", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const conversations = await storage.getConversationsByUserId(userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve conversations" });
    }
  });

  // Get messages for a conversation
  app.get("/api/conversations/:conversationId/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const messages = await storage.getMessagesByConversationId(conversationId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve messages" });
    }
  });

  // Send a message in a conversation
  app.post("/api/conversations/:conversationId/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getConversation(conversationId);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Create user message
      const userMessage = await storage.createMessage({
        conversationId,
        content: req.body.content,
        isUser: true
      });
      
      // Get conversation history for context
      const messages = await storage.getMessagesByConversationId(conversationId);
      const conversationHistory = messages.map(msg => ({
        role: msg.isUser ? "user" as const : "assistant" as const,
        content: msg.content
      }));
      
      // Get user preferences if they exist
      const preferences = await storage.getTravelPreferenceByConversationId(conversationId);
      
      // Generate AI response
      const aiResponse = await aiService.answerTravelQuestion(
        req.body.content,
        preferences ? {
          budget: preferences.budget,
          duration: preferences.duration,
          accommodationType: preferences.accommodationType || "",
          activities: preferences.activities || []
        } : null,
        conversationHistory.slice(-10) // Last 10 messages for context
      );
      
      // Save AI response
      const assistantMessage = await storage.createMessage({
        conversationId,
        content: aiResponse,
        isUser: false
      });
      
      res.status(201).json({ userMessage, assistantMessage });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to process message" });
      }
    }
  });

  // Save travel preferences
  app.post("/api/conversations/:conversationId/preferences", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getConversation(conversationId);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Save preferences
      const preferences = await storage.createTravelPreference({
        conversationId,
        budget: req.body.budget,
        duration: req.body.duration,
        accommodationType: req.body.accommodationType,
        activities: req.body.activities,
        ...(req.body.destination ? { destination: req.body.destination } : {}),
        ...(req.body.departureDateStr ? { departureDateStr: req.body.departureDateStr } : {}),
        ...(req.body.returnDateStr ? { returnDateStr: req.body.returnDateStr } : {}),
        ...(req.body.numberOfTravelers ? { numberOfTravelers: req.body.numberOfTravelers } : {}),
        ...(req.body.currency ? { currency: req.body.currency } : {})
      });

      // Get conversation history for context
      const messages = await storage.getMessagesByConversationId(conversationId);
      const conversationHistory = messages.map(msg => ({
        role: msg.isUser ? "user" as const : "assistant" as const,
        content: msg.content
      }));
      
      // Generate recommendations based on preferences
      const recommendations = await aiService.generateTravelRecommendations(
        {
          budget: preferences.budget,
          duration: preferences.duration,
          accommodationType: preferences.accommodationType || "",
          activities: preferences.activities || [],
          ...(req.body.destination ? { destination: req.body.destination } : {}),
          ...(req.body.departureDateStr ? { departureDateStr: req.body.departureDateStr } : {}),
          ...(req.body.returnDateStr ? { returnDateStr: req.body.returnDateStr } : {}),
          ...(req.body.numberOfTravelers ? { numberOfTravelers: req.body.numberOfTravelers } : {}),
          ...(req.body.currency ? { currency: req.body.currency } : {})
        },
        conversationHistory.slice(-10) // Last 10 messages for context
      );
      
      // Save recommendations
      await storage.createTravelRecommendation({
        conversationId,
        destinations: recommendations.destinations,
        travelPlan: recommendations.travelPlan
      });
      
      // Create AI response message acknowledging preferences
      const responseMessage = "شكراً لمشاركة تفضيلاتك! إليك بعض التوصيات المخصصة بناءً على اهتماماتك.";
      await storage.createMessage({
        conversationId,
        content: responseMessage,
        isUser: false
      });
      
      res.status(201).json({ preferences, recommendations });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        console.error(error);
        res.status(500).json({ message: "Failed to save preferences" });
      }
    }
  });

  // Get travel recommendations for a conversation
  app.get("/api/conversations/:conversationId/recommendations", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const recommendations = await storage.getTravelRecommendationByConversationId(conversationId);
      if (!recommendations) {
        return res.status(404).json({ message: "No recommendations found for this conversation" });
      }
      
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve recommendations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
