import { 
  User, 
  InsertUser, 
  Conversation, 
  InsertConversation, 
  Message, 
  InsertMessage, 
  TravelPreference, 
  InsertTravelPreference, 
  TravelRecommendation, 
  InsertTravelRecommendation
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Conversations
  getConversation(id: number): Promise<Conversation | undefined>;
  getConversationsByUserId(userId: number): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  
  // Messages
  getMessagesByConversationId(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Travel Preferences
  getTravelPreferenceByConversationId(conversationId: number): Promise<TravelPreference | undefined>;
  createTravelPreference(preference: InsertTravelPreference): Promise<TravelPreference>;
  
  // Travel Recommendations
  getTravelRecommendationByConversationId(conversationId: number): Promise<TravelRecommendation | undefined>;
  createTravelRecommendation(recommendation: InsertTravelRecommendation): Promise<TravelRecommendation>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private conversations: Map<number, Conversation>;
  private messages: Map<number, Message>;
  private travelPreferences: Map<number, TravelPreference>;
  private travelRecommendations: Map<number, TravelRecommendation>;
  
  private currentUserId: number;
  private currentConversationId: number;
  private currentMessageId: number;
  private currentTravelPreferenceId: number;
  private currentTravelRecommendationId: number;

  constructor() {
    this.users = new Map();
    this.conversations = new Map();
    this.messages = new Map();
    this.travelPreferences = new Map();
    this.travelRecommendations = new Map();
    
    this.currentUserId = 1;
    this.currentConversationId = 1;
    this.currentMessageId = 1;
    this.currentTravelPreferenceId = 1;
    this.currentTravelRecommendationId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Conversation methods
  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getConversationsByUserId(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.userId === userId
    );
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentConversationId++;
    const createdAt = new Date();
    // Ensure userId is never undefined, use null instead if needed
    const userId = insertConversation.userId !== undefined ? insertConversation.userId : null;
    const conversation: Conversation = { 
      ...insertConversation, 
      id, 
      createdAt,
      userId 
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  // Message methods
  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.conversationId === conversationId
    );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const createdAt = new Date();
    const message: Message = { ...insertMessage, id, createdAt };
    this.messages.set(id, message);
    return message;
  }

  // Travel Preference methods
  async getTravelPreferenceByConversationId(conversationId: number): Promise<TravelPreference | undefined> {
    return Array.from(this.travelPreferences.values()).find(
      (preference) => preference.conversationId === conversationId
    );
  }

  async createTravelPreference(insertPreference: InsertTravelPreference): Promise<TravelPreference> {
    const id = this.currentTravelPreferenceId++;
    const createdAt = new Date();
    // Ensure accommodationType and activities are never undefined
    const accommodationType = insertPreference.accommodationType ?? null;
    const activities = insertPreference.activities ?? null;
    
    const preference: TravelPreference = { 
      ...insertPreference, 
      id, 
      createdAt,
      accommodationType,
      activities 
    };
    this.travelPreferences.set(id, preference);
    return preference;
  }

  // Travel Recommendation methods
  async getTravelRecommendationByConversationId(conversationId: number): Promise<TravelRecommendation | undefined> {
    return Array.from(this.travelRecommendations.values()).find(
      (recommendation) => recommendation.conversationId === conversationId
    );
  }

  async createTravelRecommendation(insertRecommendation: InsertTravelRecommendation): Promise<TravelRecommendation> {
    const id = this.currentTravelRecommendationId++;
    const createdAt = new Date();
    
    // Ensure travelPlan is never undefined, use null for optional property
    const travelPlan = insertRecommendation.travelPlan ?? null;
    
    const recommendation: TravelRecommendation = { 
      ...insertRecommendation, 
      id, 
      createdAt, 
      travelPlan 
    };
    
    this.travelRecommendations.set(id, recommendation);
    return recommendation;
  }
}

export const storage = new MemStorage();
