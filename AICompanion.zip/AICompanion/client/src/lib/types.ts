// Types for the travel agent application

export interface User {
  id: number;
  username: string;
}

export interface Conversation {
  id: number;
  userId?: number;
  title: string;
  createdAt: Date;
}

export interface Message {
  id: number;
  conversationId: number;
  content: string;
  isUser: boolean;
  createdAt: Date;
}

export interface TravelPreference {
  id?: number;
  conversationId: number;
  budget: string;
  duration: string;
  accommodationType: string;
  activities: string[];
  destination?: string;
  departureDateStr?: string;
  returnDateStr?: string;
  numberOfTravelers?: number;
  currency?: string;
}

export interface TravelPlanDay {
  day: string;
  activities: string;
  transport?: string;
}

export interface TravelPlan {
  destination: string;
  duration: string;
  days: TravelPlanDay[];
}

export interface Destination {
  name: string;
  country: string;
  imageUrl: string;
  safetyLevel: string;
  budgetSuitability: string;
  description: string;
  estimatedCost: string;
  recommendedAccommodation: string;
  flightPrices?: {
    economy: number;
    business?: number;
  };
  transportOptions?: {
    type: string;
    cost: string;
    description?: string;
  }[];
  promotions?: string[];
  currency?: string;
}

export interface TravelRecommendation {
  id?: number;
  conversationId: number;
  destinations: Destination[];
  travelPlan?: TravelPlan;
}

export type ChatStatus = 'idle' | 'loading' | 'preferences' | 'recommendations';
