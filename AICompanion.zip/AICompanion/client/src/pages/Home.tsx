import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import ChatInterface from "@/components/ChatInterface";
import type { Conversation } from "@/lib/types";

export default function Home() {
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Mock user ID for demo purposes
  const userId = 1;
  
  // Fetch conversations
  const { 
    data: conversations = [],
    isLoading: isLoadingConversations,
    isError: isErrorConversations,
  } = useQuery({
    queryKey: [`/api/users/${userId}/conversations`],
  });
  
  // Create new conversation mutation
  const { mutate: createConversation, isPending: isCreatingConversation } = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conversations", {
        userId,
        title: "محادثة جديدة" // Default title
      });
      return await response.json();
    },
    onSuccess: (newConversation: Conversation) => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/conversations`] });
      setActiveConversationId(newConversation.id);
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء إنشاء محادثة جديدة",
        variant: "destructive",
      });
    }
  });
  
  // Create a new conversation on initial load if none exist
  useEffect(() => {
    if (!isLoadingConversations && !isErrorConversations && conversations.length === 0) {
      createConversation();
    } else if (conversations.length > 0 && !activeConversationId) {
      // Set the most recent conversation as active
      setActiveConversationId(conversations[0].id);
    }
  }, [isLoadingConversations, conversations, activeConversationId]);
  
  // Handle creating a new conversation
  const handleNewConversation = () => {
    createConversation();
  };
  
  // Handle selecting a conversation
  const handleSelectConversation = (conversation: Conversation) => {
    setActiveConversationId(conversation.id);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6 flex-grow flex flex-col lg:flex-row">
        <Sidebar 
          conversations={conversations}
          onNewConversation={handleNewConversation}
          onSelectConversation={handleSelectConversation}
          activeConversationId={activeConversationId || undefined}
        />
        
        {activeConversationId ? (
          <ChatInterface conversationId={activeConversationId} />
        ) : (
          <div className="lg:w-3/4 bg-white rounded-lg shadow-md flex items-center justify-center p-8">
            {isLoadingConversations || isCreatingConversation ? (
              <div className="loading-dots flex space-x-1">
                <div></div>
                <div></div>
                <div></div>
              </div>
            ) : (
              <p className="text-gray-500">يرجى اختيار محادثة أو إنشاء محادثة جديدة</p>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
