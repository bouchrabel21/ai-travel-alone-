import { useState } from "react";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import type { TravelPreference } from "@/lib/types";

const preferencesSchema = z.object({
  budget: z.string({
    required_error: "يرجى اختيار الميزانية",
  }),
  duration: z.string({
    required_error: "يرجى اختيار مدة الرحلة",
  }),
  accommodationType: z.string({
    required_error: "يرجى اختيار نوع الإقامة",
  }),
  activities: z.array(z.string()).min(1, {
    message: "يرجى اختيار نشاط واحد على الأقل",
  }),
  destination: z.string().optional(),
  departureDateStr: z.string().optional(),
  returnDateStr: z.string().optional(),
  numberOfTravelers: z.number().min(1).default(1),
  currency: z.string().default("DZD"),
});

interface PreferenceFormProps {
  onSubmit: (preferences: TravelPreference) => void;
  conversationId: number;
}

export default function PreferenceForm({ onSubmit, conversationId }: PreferenceFormProps) {
  const form = useForm<z.infer<typeof preferencesSchema>>({
    resolver: zodResolver(preferencesSchema),
    defaultValues: {
      budget: "",
      duration: "",
      accommodationType: "",
      activities: [],
      destination: "",
      departureDateStr: "",
      returnDateStr: "",
      numberOfTravelers: 1,
      currency: "DZD",
    },
  });

  const [selectedActivities, setSelectedActivities] = useState<string[]>([]);

  const handleActivityToggle = (activity: string) => {
    setSelectedActivities(prev => {
      const isSelected = prev.includes(activity);
      const newActivities = isSelected
        ? prev.filter(a => a !== activity)
        : [...prev, activity];
      
      form.setValue("activities", newActivities);
      return newActivities;
    });
  };

  const handleSubmit = (values: z.infer<typeof preferencesSchema>) => {
    onSubmit({
      conversationId,
      ...values,
    });
  };

  const budgetOptions = [
    { value: "أقل من 1000", label: "أقل من 1000" },
    { value: "1000-2000", label: "1000-2000" },
    { value: "2000-3000", label: "2000-3000" },
    { value: "أكثر من 3000", label: "أكثر من 3000" },
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <div className="space-y-3">
          {/* Budget Selection */}
          <FormField
            control={form.control}
            name="budget"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">ميزانيتك التقريبية (بالدولار)</FormLabel>
                <div className="flex flex-wrap gap-2">
                  {budgetOptions.map((option) => (
                    <Button
                      key={option.value}
                      type="button"
                      variant={field.value === option.value ? "default" : "outline"}
                      onClick={() => field.onChange(option.value)}
                      className="px-3 py-2"
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Duration Selection */}
          <FormField
            control={form.control}
            name="duration"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">مدة الرحلة (بالأيام)</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر مدة الرحلة" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="3-5">3-5 أيام</SelectItem>
                    <SelectItem value="6-10">6-10 أيام</SelectItem>
                    <SelectItem value="11-15">11-15 يوم</SelectItem>
                    <SelectItem value="15+">أكثر من 15 يوم</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Accommodation Type */}
          <FormField
            control={form.control}
            name="accommodationType"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">نوع الإقامة المفضل</FormLabel>
                <RadioGroup
                  onValueChange={field.onChange}
                  value={field.value}
                  className="grid grid-cols-2 gap-2"
                >
                  <div className="flex items-center border rounded-md p-2 cursor-pointer hover:bg-gray-50">
                    <RadioGroupItem value="hotel" id="hotel" className="ml-2" />
                    <Label htmlFor="hotel">فندق</Label>
                  </div>
                  <div className="flex items-center border rounded-md p-2 cursor-pointer hover:bg-gray-50">
                    <RadioGroupItem value="hostel" id="hostel" className="ml-2" />
                    <Label htmlFor="hostel">نزل</Label>
                  </div>
                  <div className="flex items-center border rounded-md p-2 cursor-pointer hover:bg-gray-50">
                    <RadioGroupItem value="apartment" id="apartment" className="ml-2" />
                    <Label htmlFor="apartment">شقة</Label>
                  </div>
                  <div className="flex items-center border rounded-md p-2 cursor-pointer hover:bg-gray-50">
                    <RadioGroupItem value="any" id="any" className="ml-2" />
                    <Label htmlFor="any">غير مهم</Label>
                  </div>
                </RadioGroup>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Activities */}
          <FormField
            control={form.control}
            name="activities"
            render={() => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">أنشطة مفضلة</FormLabel>
                <div className="flex flex-wrap gap-2">
                  {[
                    { id: "nature", label: "طبيعة" },
                    { id: "culture", label: "ثقافة" },
                    { id: "food", label: "طعام" },
                    { id: "adventure", label: "مغامرة" },
                    { id: "relax", label: "استرخاء" },
                  ].map((activity) => (
                    <Button
                      key={activity.id}
                      type="button"
                      variant={selectedActivities.includes(activity.id) ? "default" : "outline"}
                      className="px-3 py-1 rounded-full"
                      onClick={() => handleActivityToggle(activity.id)}
                    >
                      {activity.label}
                    </Button>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {/* Destination Selection */}
          <FormField
            control={form.control}
            name="destination"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">الوجهة المفضلة</FormLabel>
                <div className="space-y-2">
                  <Select onValueChange={field.onChange} value={field.value || ""}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر وجهة" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="dubai">دبي</SelectItem>
                      <SelectItem value="istanbul">إسطنبول</SelectItem>
                      <SelectItem value="paris">باريس</SelectItem>
                      <SelectItem value="london">لندن</SelectItem>
                      <SelectItem value="cairo">القاهرة</SelectItem>
                      <SelectItem value="rome">روما</SelectItem>
                      <SelectItem value="barcelona">برشلونة</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="text-xs text-gray-500">اختياري: يمكننا اقتراح وجهات إذا لم تكن متأكدًا</div>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {/* Travel Dates */}
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="departureDateStr"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel className="block text-sm font-medium mb-1">تاريخ المغادرة</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={`w-full mr-2 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                        >
                          {field.value ? format(new Date(field.value), "PPP", { locale: ar }) : <span>اختر تاريخ المغادرة</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        locale={ar}
                        mode="single"
                        selected={field.value ? new Date(field.value) : undefined}
                        onSelect={(date) => field.onChange(date ? date.toISOString() : "")}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="returnDateStr"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel className="block text-sm font-medium mb-1">تاريخ العودة</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={`w-full mr-2 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                        >
                          {field.value ? format(new Date(field.value), "PPP", { locale: ar }) : <span>اختر تاريخ العودة</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        locale={ar}
                        mode="single"
                        selected={field.value ? new Date(field.value) : undefined}
                        onSelect={(date) => field.onChange(date ? date.toISOString() : "")}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          {/* Number of Travelers */}
          <FormField
            control={form.control}
            name="numberOfTravelers"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">عدد المسافرين</FormLabel>
                <div className="flex items-center">
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    className="h-8 w-8 rounded-r-none"
                    onClick={() => field.onChange(Math.max(1, field.value - 1))}
                  >
                    -
                  </Button>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                      className="h-8 text-center rounded-none w-16 border-x-0"
                    />
                  </FormControl>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    className="h-8 w-8 rounded-l-none"
                    onClick={() => field.onChange(field.value + 1)}
                  >
                    +
                  </Button>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button type="submit" className="w-full">
          إرسال التفضيلات
        </Button>
      </form>
    </Form>
  );
}
