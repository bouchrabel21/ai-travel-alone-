import { useState, useRef, useEffect } from "react";
import { Bot, SendIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import MessageBubble from "./MessageBubble";
import PreferenceForm from "./PreferenceForm";
import QuickSuggestions from "./QuickSuggestions";
import { MarketingBanner, marketingBanners } from "./MarketingBanner";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Message, TravelPreference, ChatStatus, TravelRecommendation } from "@/lib/types";

interface ChatInterfaceProps {
  conversationId: number;
}

const ChatInterface = ({ conversationId }: ChatInterfaceProps) => {
  const [userInput, setUserInput] = useState("");
  const [chatStatus, setChatStatus] = useState<ChatStatus>("idle");
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  
  // Fetch messages for the current conversation
  const { 
    data: messages = [] as Message[], 
    isLoading: isLoadingMessages 
  } = useQuery<Message[]>({
    queryKey: [`/api/conversations/${conversationId}/messages`],
    enabled: !!conversationId,
  });
  
  // Fetch recommendations if they exist
  const { 
    data: recommendations 
  } = useQuery<TravelRecommendation>({
    queryKey: [`/api/conversations/${conversationId}/recommendations`],
    enabled: !!conversationId,
  });

  // Send message mutation
  const { mutate: sendMessage, isPending: isSendingMessage } = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("POST", `/api/conversations/${conversationId}/messages`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}/messages`] });
    },
  });

  // Submit preferences mutation
  const { mutate: submitPreferences, isPending: isSubmittingPreferences } = useMutation({
    mutationFn: async (preferences: TravelPreference) => {
      return apiRequest("POST", `/api/conversations/${conversationId}/preferences`, preferences);
    },
    onSuccess: () => {
      setChatStatus("recommendations");
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}/messages`] });
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}/recommendations`] });
    },
  });

  // Scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;
    
    // Create optimistic user message for immediate UI update
    const optimisticUserMessage: Message = {
      id: Date.now(),
      conversationId,
      content: userInput,
      isUser: true,
      createdAt: new Date(),
    };
    
    // Add optimistic message to the UI
    queryClient.setQueryData(
      [`/api/conversations/${conversationId}/messages`],
      (old: Message[] = []) => [...old, optimisticUserMessage]
    );
    
    // Send the message to the server
    sendMessage(userInput);
    setUserInput("");
    setChatStatus("loading");
  };

  // Handle quick suggestion click
  const handleSuggestionClick = (suggestion: string) => {
    setUserInput(suggestion);
  };
  
  // Handle preference form submission
  const handlePreferenceSubmit = (preferences: TravelPreference) => {
    submitPreferences(preferences);
  };

  // Show preferences form after first assistant message
  useEffect(() => {
    if (messages.length === 1 && !messages[0].isUser) {
      setChatStatus("preferences");
    }
  }, [messages]);

  return (
    <div className="lg:w-3/4 bg-white rounded-lg shadow-md overflow-hidden flex flex-col h-full">
      {/* Agent Header */}
      <div className="bg-primary text-white p-4 flex items-center">
        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center ml-3">
          <Bot className="h-5 w-5" />
        </div>
        <div>
          <h2 className="font-semibold">مساعد سفر MusaferBox</h2>
          <p className="text-sm opacity-80">يساعدك في تخطيط رحلتك المنفردة وحجز تذاكر الطيران والمواصلات</p>
        </div>
      </div>

      {/* Chat Container */}
      <div 
        ref={chatContainerRef}
        className="flex-grow overflow-y-auto p-4"
        style={{ height: "500px" }}
      >
        {/* Loading State */}
        {isLoadingMessages ? (
          <div className="flex justify-center items-center h-full">
            <div className="loading-dots flex space-x-1">
              <div></div>
              <div></div>
              <div></div>
            </div>
          </div>
        ) : (
          <>
            {/* Map through messages */}
            {messages.map((message) => (
              <MessageBubble 
                key={message.id} 
                message={message} 
                destinations={recommendations?.destinations}
                travelPlan={recommendations?.travelPlan}
              />
            ))}
            
            {/* Preferences form after initial message */}
            {chatStatus === "preferences" && (
              <div className="flex mb-4">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mr-2 flex-shrink-0">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-gray-100 rounded-lg py-3 px-4 max-w-[90%]">
                  <p className="mb-3">لمساعدتك بشكل أفضل، يرجى تزويدي ببعض المعلومات:</p>
                  <PreferenceForm 
                    onSubmit={handlePreferenceSubmit} 
                    conversationId={conversationId} 
                  />
                </div>
              </div>
            )}
            
            {/* Loading Message */}
            {(chatStatus === "loading" || isSendingMessage || isSubmittingPreferences) && (
              <div className="flex mb-4">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mr-2 flex-shrink-0">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-gray-100 rounded-lg py-2 px-4 max-w-[80%] flex items-center">
                  <div className="loading-dots flex space-x-1">
                    <div></div>
                    <div></div>
                    <div></div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Chat Input */}
      <div className="border-t border-gray-200 p-4">
        <form className="flex items-center" onSubmit={handleSubmit}>
          <Input
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            className="flex-grow py-2 px-4 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            placeholder="اكتب سؤالك أو اطلب توصيات سفر..."
            disabled={chatStatus === "preferences" || isSubmittingPreferences}
          />
          <Button 
            type="submit" 
            className="rounded-r-md"
            disabled={!userInput.trim() || chatStatus === "preferences" || isSubmittingPreferences}
          >
            <SendIcon className="h-4 w-4" />
          </Button>
        </form>

        {/* Marketing Banner */}
        {chatStatus === "recommendations" && recommendations?.destinations && (
          <div className="mt-3">
            <MarketingBanner
              title={marketingBanners[0].title}
              description={marketingBanners[0].description}
              discount={marketingBanners[0].discount}
              expiryDate={marketingBanners[0].expiryDate}
            />
          </div>
        )}
        
        {/* Quick Suggestion Pills */}
        {chatStatus !== "preferences" && (
          <QuickSuggestions onSuggestionClick={handleSuggestionClick} />
        )}
      </div>
    </div>
  );
};

export default ChatInterface;
