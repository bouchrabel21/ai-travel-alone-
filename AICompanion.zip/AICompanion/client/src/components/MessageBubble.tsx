import { Bot, UserIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Message } from "@/lib/types";
import { DestinationCard } from "./DestinationCard";
import { TravelPlan } from "./TravelPlan";

interface MessageBubbleProps {
  message: Message;
  destinations?: any[];
  travelPlan?: any;
}

// Function to detect JSON pattern in message content
const tryParseJSON = (text: string) => {
  try {
    // Look for JSON patterns like { "destinations": [...] }
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    return null;
  } catch (e) {
    return null;
  }
};

// Function to process message content
const processMessageContent = (content: string) => {
  // Check if content has recommendations pattern
  if (content.includes("إليك بعض الوجهات المقترحة") ||
      content.includes("بناءً على تفضيلاتك")) {
    
    const jsonData = tryParseJSON(content);
    if (jsonData && jsonData.destinations) {
      // Extract the text before the JSON data
      const textMatch = content.match(/([\s\S]*?)(\{[\s\S]*\})/);
      const introText = textMatch ? textMatch[1] : "";
      
      return {
        introText,
        jsonData
      };
    }
  }
  
  return { introText: content, jsonData: null };
};

const MessageBubble = ({ message, destinations, travelPlan }: MessageBubbleProps) => {
  const { isUser, content } = message;
  
  // Process message content to extract any structured data
  const { introText, jsonData } = processMessageContent(content);
  
  // If we have jsonData from the message OR external destinations/travelPlan props
  const hasRecommendations = jsonData?.destinations || destinations;
  const hasTravelPlan = jsonData?.travelPlan || travelPlan;
  
  return (
    <div className={cn("flex mb-4", isUser ? "justify-end" : "")}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mr-2 flex-shrink-0">
          <Bot className="h-4 w-4 text-white" />
        </div>
      )}
      
      <div className={cn(
        "rounded-lg py-2 px-4 max-w-[90%]",
        isUser ? "bg-primary text-white" : "bg-gray-100"
      )}>
        {/* Regular text content */}
        <p className={cn(hasRecommendations ? "mb-4" : "")}>{introText}</p>
        
        {/* Recommendations if available */}
        {hasRecommendations && (
          <div className="space-y-4 mt-4">
            {(jsonData?.destinations || destinations)?.map((destination, index) => (
              <DestinationCard key={index} destination={destination} />
            ))}
          </div>
        )}
        
        {/* Travel Plan if available */}
        {hasTravelPlan && (
          <div className="mt-4">
            <TravelPlan plan={jsonData?.travelPlan || travelPlan} />
          </div>
        )}
      </div>
      
      {isUser && (
        <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center ml-2 flex-shrink-0">
          <UserIcon className="h-4 w-4 text-white" />
        </div>
      )}
    </div>
  );
};

export default MessageBubble;
