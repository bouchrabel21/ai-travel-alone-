import { useState } from "react";
import { PlusIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Conversation } from "@/lib/types";

interface SidebarProps {
  conversations: Conversation[];
  onNewConversation: () => void;
  onSelectConversation: (conversation: Conversation) => void;
  activeConversationId?: number;
}

const Sidebar = ({
  conversations,
  onNewConversation,
  onSelectConversation,
  activeConversationId
}: SidebarProps) => {
  const formatDate = (dateInput: Date | string) => {
    // Ensure the date is a proper Date object
    const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
    
    // Check if date is valid
    if (isNaN(date.getTime())) {
      return "تاريخ غير معروف";
    }
    
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diff === 0) return "اليوم";
    if (diff === 1) return "أمس";
    if (diff < 7) return `منذ ${diff} أيام`;
    if (diff < 14) return "منذ أسبوع";
    if (diff < 21) return "منذ أسبوعين";
    if (diff < 30) return "منذ أسابيع";
    
    return "منذ شهر أو أكثر";
  };

  return (
    <aside className="lg:w-1/4 mb-6 lg:mb-0 lg:ml-6">
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">مرحبا بك!</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">مساعد السفر الذكي يساعدك في التخطيط لرحلتك المنفردة التالية</p>
          <div className="border-t border-gray-200 pt-4 mt-4">
            <h3 className="font-medium mb-2">ابدأ محادثة جديدة</h3>
            <Button 
              className="w-full"
              onClick={onNewConversation}
            >
              محادثة جديدة <PlusIcon className="h-4 w-4 mr-2" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">محادثات سابقة</CardTitle>
        </CardHeader>
        <CardContent>
          {conversations.length > 0 ? (
            <ul className="space-y-2">
              {conversations.map((conversation) => (
                <li 
                  key={conversation.id}
                  className={`p-2 hover:bg-gray-50 rounded cursor-pointer flex justify-between items-center transition-colors ${
                    activeConversationId === conversation.id ? "bg-gray-100" : ""
                  }`}
                  onClick={() => onSelectConversation(conversation)}
                >
                  <span>{conversation.title}</span>
                  <span className="text-xs text-gray-500">
                    {formatDate(conversation.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500 text-center py-4">
              لا توجد محادثات سابقة
            </p>
          )}
        </CardContent>
      </Card>
    </aside>
  );
};

export default Sidebar;
