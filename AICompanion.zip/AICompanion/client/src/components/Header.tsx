import { BellIcon, UserIcon } from "lucide-react";

const Header = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          {/* Logo would be replaced with actual company logo */}
          <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center text-white mr-3">
            <span className="font-bold">MB</span>
          </div>
          <h1 className="text-xl font-bold text-primary">مسافر بوكس</h1>
        </div>
        <div className="flex items-center space-x-4">
          <button className="p-2 rounded-full hover:bg-gray-100 ml-2">
            <BellIcon className="h-5 w-5 text-gray-600" />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100">
            <UserIcon className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
