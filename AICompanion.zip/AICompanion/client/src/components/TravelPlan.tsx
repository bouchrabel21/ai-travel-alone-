import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Bus, Car, Train } from "lucide-react";
import type { TravelPlan as TravelPlanType } from "@/lib/types";

interface TravelPlanProps {
  plan: TravelPlanType;
}

export const TravelPlan = ({ plan }: TravelPlanProps) => {
  const [expanded, setExpanded] = useState(false);
  
  // Get the icon for transport type
  const getTransportIcon = (type: string = "") => {
    if (!type) return null;
    
    const lowerType = type.toLowerCase();
    if (lowerType.includes("حافلة") || lowerType.includes("bus")) {
      return <Bus className="h-4 w-4 text-primary mr-1 inline-block" />;
    }
    if (lowerType.includes("قطار") || lowerType.includes("train")) {
      return <Train className="h-4 w-4 text-primary mr-1 inline-block" />;
    }
    return <Car className="h-4 w-4 text-primary mr-1 inline-block" />;
  };
  
  return (
    <Card className="mt-4 border border-gray-200 rounded-lg bg-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">خطة سفر مقترحة: {plan.destination} ({plan.duration})</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2 text-sm">
          {/* Show first 3 days by default or all if expanded */}
          {plan.days.slice(0, expanded ? plan.days.length : 3).map((day, index) => (
            <li key={index} className="flex flex-col mb-2">
              <div className="flex">
                <span className="font-semibold w-20">اليوم {day.day}:</span>
                <span>{day.activities}</span>
              </div>
              {day.transport && (
                <div className="mt-1 mr-20 text-xs text-gray-600 flex items-center">
                  {getTransportIcon(day.transport)}
                  <span>وسيلة التنقل: {day.transport}</span>
                </div>
              )}
            </li>
          ))}
        </ul>
        
        {/* Show "show more" button only if there are more than 3 days */}
        {plan.days.length > 3 && (
          <Button 
            variant="link" 
            className="mt-3 p-0 text-primary text-sm font-medium"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? "عرض أقل" : "عرض الخطة الكاملة"}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
