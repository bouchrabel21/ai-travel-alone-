import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Tag, X } from 'lucide-react';

interface MarketingBannerProps {
  title: string;
  description: string;
  discount?: string;
  expiryDate?: string;
  onClose?: () => void;
}

export const MarketingBanner = ({
  title,
  description, 
  discount,
  expiryDate,
  onClose
}: MarketingBannerProps) => {
  const [visible, setVisible] = useState(true);

  const handleClose = () => {
    setVisible(false);
    onClose?.();
  };

  if (!visible) return null;

  return (
    <div className="promotion-banner">
      <div className="flex justify-between items-start">
        <div className="flex items-center mb-1">
          <Tag className="h-5 w-5 mr-2 flex-shrink-0" />
          <h3 className="font-bold text-lg">{title}</h3>
        </div>
        {onClose && (
          <button 
            onClick={handleClose}
            className="text-white/80 hover:text-white hover:bg-black/10 rounded-full p-1"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      <p className="mb-2 text-sm">{description}</p>
      
      <div className="flex flex-wrap justify-between items-center gap-2">
        {discount && (
          <span className="bg-white/20 px-2 py-1 rounded text-sm">
            خصم <span className="font-bold price-highlight">{discount}</span>
          </span>
        )}
        {expiryDate && (
          <span className="text-xs">
            ينتهي العرض: {expiryDate}
          </span>
        )}
        <Button 
          variant="secondary" 
          size="sm" 
          className="bg-white text-red-500 hover:bg-white/90 hover:text-red-600"
        >
          احجز الآن
        </Button>
      </div>
    </div>
  );
};

// Predefined marketing banners to use in the application
export const marketingBanners = [
  {
    id: 'summer-sale',
    title: 'عروض الصيف',
    description: 'استمتع بأفضل العروض على الرحلات إلى أوروبا هذا الصيف',
    discount: '20%',
    expiryDate: '15/06/2025'
  },
  {
    id: 'special-promo',
    title: 'عرض خاص لشهر رمضان',
    description: 'رحلات عائلية بأسعار مميزة إلى تركيا ومصر والمغرب',
    discount: '15%',
    expiryDate: '30/06/2025'
  },
  {
    id: 'weekend-getaway',
    title: 'عروض نهاية الأسبوع',
    description: 'رحلات قصيرة لمدة 3 أيام بأسعار منافسة',
    discount: '10%',
    expiryDate: '30/06/2025'
  }
];