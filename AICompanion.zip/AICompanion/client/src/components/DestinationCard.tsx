import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Plane, Tag, Bus, Car, Train } from "lucide-react";
import type { Destination } from "@/lib/types";

interface DestinationCardProps {
  destination: Destination;
}

export const DestinationCard = ({ destination }: DestinationCardProps) => {
  // Function to convert USD to DZD (using fixed rate for demonstration)
  const toDZD = (usdAmount: number) => {
    const conversionRate = 135.27; // USD to DZD conversion rate
    return Math.round(usdAmount * conversionRate).toLocaleString('ar-DZ');
  };
  
  // For demonstration purposes, create flight prices if they don't exist
  const flightPrices = destination.flightPrices || {
    economy: 450
  };
  
  // Example promotions if not provided
  const promotions = destination.promotions || [];
  
  // Example transport options if not provided
  const transportOptions = destination.transportOptions || [
    {
      type: "حافلة",
      cost: "5-10 د.ج",
      description: "وسائل النقل العام المتاحة بأسعار معقولة"
    },
    {
      type: "سيارة أجرة",
      cost: "50-100 د.ج",
      description: "مناسبة للمسافات القصيرة"
    }
  ];
  
  // Get the icon for transport type
  const getTransportIcon = (type: string) => {
    const lowerType = type.toLowerCase();
    if (lowerType.includes("حافلة") || lowerType.includes("bus")) return <Bus className="h-4 w-4 text-primary mr-2 flex-shrink-0" />;
    if (lowerType.includes("قطار") || lowerType.includes("train")) return <Train className="h-4 w-4 text-primary mr-2 flex-shrink-0" />;
    return <Car className="h-4 w-4 text-primary mr-2 flex-shrink-0" />;
  };
  
  return (
    <Card className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="md:flex">
        <div className="md:w-1/3 relative">
          <img 
            src={destination.imageUrl} 
            alt={`${destination.name}, ${destination.country}`} 
            className="h-48 w-full object-cover"
          />
          {promotions.length > 0 && (
            <div className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold px-2 py-1 m-2 rounded">
              عرض خاص
            </div>
          )}
        </div>
        <div className="p-4 md:w-2/3">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold text-lg">{destination.name}، {destination.country}</h3>
            <div className="flex items-center text-sm font-medium text-primary-600">
              <Plane className="inline-block h-4 w-4 mr-1" />
              <span className="dir-ltr">{toDZD(flightPrices.economy)} د.ج</span>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-1 mb-2">
            <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200">
              {destination.safetyLevel}
            </Badge>
            <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-200">
              {destination.budgetSuitability}
            </Badge>
          </div>
          
          <p className="text-gray-600 text-sm mb-3">{destination.description}</p>
          
          <Tabs defaultValue="details" className="w-full">
            <TabsList className="mb-2">
              <TabsTrigger value="details">التفاصيل</TabsTrigger>
              <TabsTrigger value="flights">تذاكر الطيران</TabsTrigger>
              <TabsTrigger value="transport">المواصلات</TabsTrigger>
              {promotions.length > 0 && <TabsTrigger value="promotions">عروض خاصة</TabsTrigger>}
            </TabsList>
            
            <TabsContent value="details" className="text-sm">
              <p><span className="font-medium">تكلفة تقديرية:</span> {destination.estimatedCost}</p>
              <p><span className="font-medium">أماكن إقامة مقترحة:</span> {destination.recommendedAccommodation}</p>
            </TabsContent>
            
            <TabsContent value="flights" className="text-sm">
              <div className="space-y-2">
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span>الدرجة الاقتصادية</span>
                  <span className="font-bold dir-ltr">{toDZD(flightPrices.economy)} د.ج</span>
                </div>
                {flightPrices.business && (
                  <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <span>درجة رجال الأعمال</span>
                    <span className="font-bold dir-ltr">{toDZD(flightPrices.business)} د.ج</span>
                  </div>
                )}
                <div className="text-xs text-gray-500 flex items-center mt-1">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  الأسعار تقريبية وتختلف حسب تاريخ الحجز
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="transport" className="text-sm">
              <div className="space-y-2">
                {transportOptions.map((transport, index) => (
                  <div key={index} className="flex items-start p-2 bg-gray-50 rounded">
                    {getTransportIcon(transport.type)}
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <span className="font-semibold">{transport.type}</span>
                        <span className="dir-ltr">{transport.cost}</span>
                      </div>
                      {transport.description && (
                        <p className="text-xs text-gray-600 mt-1">{transport.description}</p>
                      )}
                    </div>
                  </div>
                ))}
                <div className="text-xs text-gray-500 flex items-center mt-1">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  أسعار المواصلات تقريبية وقد تختلف
                </div>
              </div>
            </TabsContent>
            
            {promotions.length > 0 && (
              <TabsContent value="promotions" className="text-sm">
                <div className="space-y-2">
                  {promotions.map((promo, index) => (
                    <div key={index} className="flex items-start p-2 border border-red-100 bg-red-50 rounded">
                      <Tag className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{promo}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
            )}
          </Tabs>
        </div>
      </div>
    </Card>
  );
};
