import { Button } from "@/components/ui/button";

interface QuickSuggestionsProps {
  onSuggestionClick: (suggestion: string) => void;
}

const suggestedQuestions = [
  "أوصي بوجهة آمنة للنساء المسافرات بمفردهن",
  "أفضل الوجهات للسفر المنفرد بميزانية محدودة",
  "نصائح للسفر المنفرد للمرة الأولى",
];

const QuickSuggestions = ({ onSuggestionClick }: QuickSuggestionsProps) => {
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {suggestedQuestions.map((question, index) => (
        <Button
          key={index}
          variant="ghost"
          className="text-xs bg-gray-100 hover:bg-gray-200 rounded-full px-3 py-1 text-gray-700 h-auto"
          onClick={() => onSuggestionClick(question)}
        >
          {question}
        </Button>
      ))}
    </div>
  );
};

export default QuickSuggestions;
